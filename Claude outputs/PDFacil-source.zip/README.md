# PDFacil

An easy PDF viewer and editor for Windows, with a Word-style ribbon.

## Run
Double-click `PDFacil-1.0.0-portable.exe`. No installation needed.
Tip: right-click any PDF > Open with > Choose another app > browse to the exe, to open PDFs with PDFacil.

## Ribbon
- **File**: Open, Save, Save As, Print, Recent, Close
- **Pages**: First/Previous/Next/Last, Go to page, Rotate left/right, Delete page
- **Comment**: Select, Highlight, Text, Comment (sticky note), colors, font size, Remove
- **View**: Zoom in/out, 100%, Fit width, Fit page, Search, Thumbnails

## Shortcuts
| Keys | Action |
|---|---|
| Ctrl+O / Ctrl+S / Ctrl+Shift+S | Open / Save / Save As |
| Ctrl+P | Print |
| Ctrl+Z / Ctrl+Y | Undo / Redo |
| Ctrl+F, F3 | Search, next match |
| Ctrl+G | Go to page |
| Ctrl + mouse wheel, Ctrl +/-, Ctrl+0 | Zoom, 100% |
| V / H / T / N | Select / Highlight / Text / Comment tool |
| Delete | Remove selected highlight, text or comment (or selected pages in the thumbnail bar) |
| Esc | Finish editing, back to Select |

Highlights, text boxes and comments are saved as standard PDF annotations, so Acrobat, Edge and Chrome show them. Reopening a file in PDFacil makes them editable again.

## Build from source
```
npm install
npm start                 # run in development
npm run dist              # build dist/PDFacil-<version>-portable.exe
```
